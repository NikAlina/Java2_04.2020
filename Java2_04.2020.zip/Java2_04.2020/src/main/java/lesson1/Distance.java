package lesson1;


public class Distance {
    private int id;
    private int length;

    public Distance(int id, int length) {
        this.id = id;
        this.length = length;
    }

    public int getId() {
        return id;
    }

    public int getLength() {
        return length;
    }
}
